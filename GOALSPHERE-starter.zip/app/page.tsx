"use client";

import { useEffect, useState } from "react";

type Match = {
  id: string;
  home: string;
  away: string;
  score: string;
  status: string;
  competition: string;
};

const sampleMatches: Match[] = [
  { id: "demo-1", home: "Equipo local", away: "Equipo visitante", score: "— : —", status: "Próximo", competition: "Ejemplo de demostración" },
  { id: "demo-2", home: "Club del Norte", away: "Club del Sur", score: "2 : 1", status: "Finalizado", competition: "Ejemplo histórico" },
];

const sections = ["Todos", "En directo", "Hoy", "Próximos", "Finalizados"];

export default function Home() {
  const [active, setActive] = useState("Todos");
  const [query, setQuery] = useState("");
  const [matches, setMatches] = useState<Match[]>(sampleMatches);
  const [apiMessage, setApiMessage] = useState("Datos de demostración: conecta una API para ver marcadores reales.");
  const [favorites, setFavorites] = useState<string[]>([]);
  const [user, setUser] = useState<{ name?: string | null; image?: string | null } | null>(null);

  useEffect(() => {
    try {
      setFavorites(JSON.parse(localStorage.getItem("goalsphere-favorites") || "[]"));
    } catch { setFavorites([]); }
    fetch("/api/auth/session")
      .then((r) => r.json())
      .then((session) => setUser(session?.user ?? null))
      .catch(() => {});
    fetch("/api/football")
      .then((r) => r.json())
      .then((data) => {
        setApiMessage(data.message || "Datos deportivos");
        if (Array.isArray(data.matches) && data.matches.length) setMatches(data.matches);
      })
      .catch(() => setApiMessage("No se pudo consultar la configuración de datos deportivos."));
  }, []);

  function toggleFavorite(name: string) {
    const next = favorites.includes(name) ? favorites.filter((x) => x !== name) : [...favorites, name];
    setFavorites(next);
    localStorage.setItem("goalsphere-favorites", JSON.stringify(next));
  }

  const filtered = matches.filter((m) => `${m.home} ${m.away} ${m.competition}`.toLowerCase().includes(query.toLowerCase()));

  return (
    <main>
      <header className="topbar">
        <a className="brand" href="#"><span className="brand-icon">⚽</span> GOAL<span>SPHERE</span></a>
        <nav><a href="#partidos">Partidos</a><a href="#ligas">Ligas</a><a href="#historia">Historia</a></nav>
        <a className="login" href={user ? "/api/auth/signout" : "/api/auth/signin/google"}>
          {user ? (user.name || "Mi cuenta") : "Continuar con Google"}
        </a>
      </header>

      <section className="hero">
        <div className="eyebrow"><span className="pulse" /> EL FÚTBOL NO TIENE FRONTERAS</div>
        <h1>Todo el fútbol.<br /><span>Todo el mundo.</span></h1>
        <p>Partidos, competiciones y temporadas históricas en un solo lugar.</p>
        <div className="hero-actions"><a className="primary" href="#partidos">Explorar partidos ↗</a><a className="secondary" href="#ligas">Descubrir ligas</a></div>
        <div className="hero-ball" aria-hidden="true">⚽</div>
      </section>

      <section className="content" id="partidos">
        <div className="section-heading"><div><span className="kicker">CENTRO DE PARTIDOS</span><h2>El mundo del fútbol</h2></div><span className="live-label"><span className="pulse" /> COBERTURA GLOBAL</span></div>
        <div className="toolbar">
          <div className="filters">{sections.map((s) => <button key={s} className={active === s ? "filter active" : "filter"} onClick={() => setActive(s)}>{s}</button>)}</div>
          <input aria-label="Buscar equipos o competiciones" placeholder="Buscar equipo o liga..." value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        <p className="notice">{apiMessage}</p>
        <div className="match-list">
          {filtered.map((m) => <article className="match-card" key={m.id}>
            <div className="competition">{m.competition}</div>
            <div className="teams"><div><span className="team-mark">H</span><b>{m.home}</b></div><div><span className="team-mark">A</span><b>{m.away}</b></div></div>
            <div className="match-result"><strong>{m.score}</strong><span>{m.status}</span></div>
            <button className={favorites.includes(m.home) ? "star saved" : "star"} onClick={() => toggleFavorite(m.home)} aria-label={`Guardar ${m.home} como favorito`}>{favorites.includes(m.home) ? "★" : "☆"}</button>
          </article>)}
          {filtered.length === 0 && <p className="empty">No se encontraron partidos con esa búsqueda.</p>}
        </div>
        <p className="demo-note">Los encuentros que aparecen ahora son ejemplos de diseño, no resultados reales.</p>
      </section>

      <section className="feature-grid" id="ligas">
        <article><span>🌍</span><h3>Ligas del mundo</h3><p>Explora países y competiciones, según la cobertura de la fuente deportiva.</p></article>
        <article id="historia"><span>📚</span><h3>Fútbol histórico</h3><p>Consulta temporadas y resultados antiguos cuando estén disponibles en la API.</p></article>
        <article><span>📊</span><h3>Datos y estadísticas</h3><p>Marcadores, tablas, goleadores y eventos, según los datos contratados.</p></article>
      </section>

      <footer><a className="brand" href="#">⚽ GOAL<span>SPHERE</span></a><p>Todo el fútbol. Todos los países. Toda la historia disponible.</p><small>Los datos reales se mostrarán cuando se configure un proveedor deportivo.</small></footer>
    </main>
  );
}
