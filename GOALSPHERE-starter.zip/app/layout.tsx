import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "GOALSPHERE | Todo el fútbol mundial",
  description: "Partidos, ligas, resultados y temporadas históricas del fútbol mundial.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
